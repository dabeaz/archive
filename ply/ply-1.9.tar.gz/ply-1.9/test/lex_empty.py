# lex_token.py
#
# No rules defined

import lex

tokens = [
    "PLUS",
    "MINUS",
    "NUMBER",
    ]

import sys
sys.tracebacklimit = 0

lex.lex()


