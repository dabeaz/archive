# lextab.py. This file automatically created by PLY (version 3.7). Don't edit!
_tabversion   = '3.5'
_lextokens    = {'RPAREN', 'LPAREN', 'TIMES', 'NAME', 'DIVIDE', 'PLUS', 'NUMBER', 'EQUALS', 'MINUS'}
_lexreflags   = 0
_lexliterals  = ''
_lexstateinfo = {'INITIAL': 'inclusive'}
_lexstatere   = {'INITIAL': [('(?P<t_NUMBER>\\d+)|(?P<t_newline>\\n+)|(?P<t_NAME>[a-zA-Z_][a-zA-Z0-9_]*)|(?P<t_PLUS>\\+)|(?P<t_RPAREN>\\))|(?P<t_TIMES>\\*)|(?P<t_LPAREN>\\()|(?P<t_DIVIDE>/)|(?P<t_MINUS>-)|(?P<t_EQUALS>=)', [None, ('t_NUMBER', 'NUMBER'), ('t_newline', 'newline'), (None, 'NAME'), (None, 'PLUS'), (None, 'RPAREN'), (None, 'TIMES'), (None, 'LPAREN'), (None, 'DIVIDE'), (None, 'MINUS'), (None, 'EQUALS')])]}
_lexstateignore = {'INITIAL': ' \t'}
_lexstateerrorf = {'INITIAL': 't_error'}
_lexstateeoff = {}
