# lex_token.py
#
# Missing t_error() rule

import sys
sys.path.append("..")

import ply.lex as lex

tokens = [
    "PLUS",
    "MINUS",
    "NUMBER",
    ]

t_PLUS = r'\+'
t_MINUS = r'-'
t_NUMBER = r'\d+'

sys.tracebacklimit = 0

lex.lex()


