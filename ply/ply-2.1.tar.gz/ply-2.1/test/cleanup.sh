#!/bin/sh

rm -f *~ *.pyc *.dif *.out 

