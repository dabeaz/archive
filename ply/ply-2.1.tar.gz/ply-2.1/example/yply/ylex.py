# lexer for yacc-grammars
#
# Author: David Beazley (dave@dabeaz.com)
# Date  : October 2, 2006

import sys
sys.path.append("../..")

from ply import *

tokens = (
    'LITERAL','SECTION','TOKEN','LEFT','RIGHT','PREC','START','TYPE','NONASSOC','UNION','CODE',
    'ID','QLITERAL','NUMBER',
)
literals = [ ';', ',', '<', '>', '|',':' ]

t_ignore = ' \t'

t_TOKEN     = r'%token'
t_LEFT      = r'%left'
t_RIGHT     = r'%right'
t_NONASSOC  = r'%nonassoc'
t_PREC      = r'%prec'
t_START     = r'%start'
t_TYPE      = r'%type'
t_UNION     = r'%union'
t_ID        = r'[a-zA-Z_][a-zA-Z_0-9]*'
t_QLITERAL  = r'''(?P<quote>['"]).*?(?P=quote)'''
t_NUMBER    = r'\d+'

def t_SECTION(t):
    r'%%'
    if getattr(t.lexer,"lastsection",0):
         t.value = t.lexer.lexdata[t.lexpos+2:]
         t.lexer.lexpos = len(t.lexer.lexdata)
    else:
         t.lexer.lastsection = 0
    return t

# Comments
def t_ccomment(t):
    r'/\*(.|\n)*?\*/'
    t.lineno += t.value.count('\n')

def t_cppcomment(t):
    r'//.*'
    pass

def t_LITERAL(t):
   r'%\{(.|\n)*?%\}'
   t.lexer.lineno += t.value.count("\n")
   return t

def t_NEWLINE(t):
   r'\n'
   t.lexer.lineno += 1

# Skip over quoted text.
def skip_quote(text,i):
    quote = text[i]
    i = i + 1
    while i < len(text):
        if text[i] == quote: return i+1
        if text[i] == '\\': i = i + 1
        i = i + 1
    return -1

# Skips over the remainder of a C comment
def skip_c_comment(text,i):
    while i < len(text)-1:
        if text[i:i+2] == '*/': return i+2
        i = i + 1
    return -1

# Skips over the remainder of a line
def skip_line(text,i):
    while i < len(text):
         if text[i] == '\n': return i+1
         i = i + 1
    return i

def t_CODE(t):
    r'\{'
    i = t.lexpos + 1
    text = t.lexer.lexdata
    lentext = len(text)
    level = 1

    while i < lentext:
        if text[i] == '}':
           level -= 1
           if level == 0: break
        elif text[i] == '{':
           level +=1
        elif text[i] in "'\"":
           newi = skip_quote(text,i)
           if newi < 0:
                print "%d: Unterminated string" % t.lineno
                raise SyntaxError
           i = newi
           continue
        elif text[i:i+2] == '/*':
           newi = skip_c_comment(text,i+2)
           if newi < 0:
                print "%d: Unterminated C comment" % t.lineno
                raise SyntaxError
           i = newi
           continue
        elif text[i:i+2] == '//':
            i = skip_line(text,i)
            t.lexer.lineno += 1
            continue
        elif text[i] == '\n':
            t.lexer.lineno += 1
        i += 1
    t.value = text[t.lexpos:i+1]
    t.lexer.lexpos = i+1
    return t

def t_error(t):
    print "%d: Illegal character '%s'" % (t.lineno, t.value[0])
    print t.value
    t.skip(1)

lex.lex()

if __name__ == '__main__':
    lex.runmain()

            
            
           

        

